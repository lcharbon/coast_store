module.exports.handler = (event, context, callback) => {
	const requestBody = JSON.parse(event.body);
	const order = requestBody.order;

	if (!order || !order.metadata || !order.metadata.tax_amount) {
		return callback(null, {
			statusCode: 400,
			headers: {
				'Access-Control-Allow-Origin': '*',
			},
			body: "Missing values.",
		});
	}

	const responseBody = {
		"order_update": {
			"items": [
				{
					"parent": null,
					"type": "tax",
					"description": "Sales taxes",
					"amount": parseInt(order.metadata.tax_amount),
					"currency": order.currency
				}
			],
			"shipping_methods": [
			]
		}
	}

	callback(null, {
		statusCode: 200,
		headers: {
			'Access-Control-Allow-Origin': '*',
		},
		body: JSON.stringify(responseBody),
	});
};